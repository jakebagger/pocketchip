cd /home/chip/chipcraft-master/mcpi
export LD_PRELOAD=./libbcm_host.so
export LD_LIBRARY_PATH=$PWD
./minecraft-pi
